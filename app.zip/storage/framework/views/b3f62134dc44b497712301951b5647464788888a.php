<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <h1>About Us</h1>
    <p>This example is a quick exercise to illustrate how the default, static navbar and fixed to top navbar work. It
        includes the responsive CSS and HTML, so it also adapts to your viewport and device.</p>
    <p>
        <a class="btn btn-lg btn-primary" href="/" role="button">View navbar docs &raquo;</a>
    </p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>